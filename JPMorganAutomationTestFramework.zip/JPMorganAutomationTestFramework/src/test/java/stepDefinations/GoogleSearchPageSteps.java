package stepDefinations;

import org.junit.Assert;

import com.pages.GoogleSearchPage;
import com.qa.factory.DriverFactory;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GoogleSearchPageSteps {
    
	private GoogleSearchPage GoogleSearchPage=new GoogleSearchPage(DriverFactory.getDriver());
	private static String title;
	
	@Given("user is on google search page")
	public void user_is_on_google_search_page() {
		DriverFactory.getDriver()
		.get("www.google.co.in");
		
	}

	@When("user gets the title of the page")
	public void user_gets_the_title_of_the_page() {
		title=GoogleSearchPage.getGoogleSearcgPageTitle();
		System.out.println("Page title is: " + title);
	
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String expectedTitleName) {
		Assert.assertTrue(title.contains(expectedTitleName));
	   
	}

	@When("user enters {string} in search button")
	public void user_enters_in_search_button(String string) {
		GoogleSearchPage.enterJPMorgan("JPMorgan");
		
	}

	@And("user clicks on submit button")
	public void user_clicks_on_login_button() {
		GoogleSearchPage.clickSubmitButton();
	}
}	
