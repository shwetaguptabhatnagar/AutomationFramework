package stepDefinations;

import org.junit.Assert;

import com.pages.GoogleSearchPage;
import com.pages.ResultPage;
import com.qa.factory.DriverFactory;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ResultPageSteps {
    
	private GoogleSearchPage GoogleSearchPage=new GoogleSearchPage(DriverFactory.getDriver());
	private ResultPage ResultPage;
	private static String title;
	
	@Given("user has already search for JPMorgan")
	public void user_has_already_search_for_jp_morgan() {
		DriverFactory.getDriver().get("www.google.co.in");
		ResultPage=GoogleSearchPage.doSearching("JPMorgan");
	}

	@Given("user is on Result Page")
	public void user_is_on_result_page() {
		
		title = ResultPage.getResultPageTitle();
		System.out.println("Result Page title is: " + title);
	}
	
	@When("user gets title {string}")
	public void user_gets_title(String string) {
		Assert.assertTrue(title.contains(string));
	}

	@Then("JPMorgan logo is displayed")
	public void jp_morgan_logo_is_displayed() {
		ResultPage.IsLogoPresentOrNot();
	}

}	
