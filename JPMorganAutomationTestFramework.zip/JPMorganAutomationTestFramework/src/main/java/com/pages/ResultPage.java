package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class ResultPage {
	private WebDriver driver;

	// 1. By Locators: OR
	private By companylogo = By.xpath("//img[@id='wp_thbn_47']");

	// 2. Constructor of the page class:
	public ResultPage(WebDriver driver) {
		this.driver = driver;
	}

	// 3. page actions: features(behavior) of the page the form of methods:
	public String getResultPageTitle() {
		return driver.getTitle();
	}
	
	
	public void IsLogoPresentOrNot() {
		
		WebElement img=driver.findElement(companylogo);
		// Javascript executor to check image
	      Boolean p = (Boolean) ((JavascriptExecutor)driver) .executeScript("return arguments[0].complete " + "&& typeof arguments[0].naturalWidth != \"undefined\" " + "&& arguments[0].naturalWidth > 0", img);

	      //verify if status is true
	      if (p) {
	         System.out.println("Logo present");
	      } else {
	         System.out.println("Logo not present");
	      }
	}

}

