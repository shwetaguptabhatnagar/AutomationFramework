package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GoogleSearchPage {
	private WebDriver driver;

	// 1. By Locators: OR
	private By submitButton = By.name("q");
	private By searchContent = By.xpath("//ul");

	// 2. Constructor of the page class:
	public GoogleSearchPage(WebDriver driver) {
		this.driver = driver;
	}

	// 3. page actions: features(behavior) of the page the form of methods:

	public String getGoogleSearcgPageTitle() {
		return driver.getTitle();
	}

	public void enterJPMorgan(String companyname) {
		driver.findElement(submitButton).sendKeys(companyname);
	}
	public void clickSubmitButton() {
		driver.findElement(submitButton).submit();
	}
	
	
	public ResultPage doSearching(String companyname) {
		System.out.println("Search content: " +companyname);
		driver.findElement(submitButton).sendKeys(companyname);
	    WebDriverWait w = new WebDriverWait(driver, 5);
	    w.until(ExpectedConditions.presenceOfElementLocated(searchContent));
	    driver.findElement(submitButton).submit();	
		return new ResultPage(driver);
	}

}

